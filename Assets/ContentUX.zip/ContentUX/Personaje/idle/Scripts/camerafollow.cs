using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Target")]
    public Transform target;              // Arrastra aqu� el Transform del jugador
    public Vector3 offset = new Vector3(0f, 6f, -8f);

    [Header("Suavizado")]
    [Tooltip("M�s bajo = c�mara m�s r�pida/r�gida. M�s alto = m�s suave/lenta.")]
    public float smoothTime = 0.15f;
    private Vector3 velocity = Vector3.zero;

    [Header("L�mites del escenario")]
    public bool useBounds = true;
    public Vector2 xLimits = new Vector2(-20f, 20f);
    public Vector2 zLimits = new Vector2(-20f, 20f);

    [Header("Mirada")]
    public bool lookAtTarget = true;
    public float lookHeightOffset = 1.5f;

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desiredPosition = target.position + offset;

        if (useBounds)
        {
            desiredPosition.x = Mathf.Clamp(desiredPosition.x, xLimits.x, xLimits.y);
            desiredPosition.z = Mathf.Clamp(desiredPosition.z, zLimits.x, zLimits.y);
        }

        transform.position = Vector3.SmoothDamp(
            transform.position,
            desiredPosition,
            ref velocity,
            smoothTime
        );

        if (lookAtTarget)
        {
            transform.LookAt(target.position + Vector3.up * lookHeightOffset);
        }
    }
}